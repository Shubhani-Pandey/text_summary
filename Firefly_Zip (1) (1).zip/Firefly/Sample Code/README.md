# text_summarization_using_GA
Text summarization code in python using Genetic Algorithm and nltk library
